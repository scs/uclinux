/*
 *  libsdlmain_prefix.h
 *  SDLTest
 *
 *  Created by Darrell Walisser on Wed Aug 06 2003.
 *  Copyright (c) 2003 __MyCompanyName__. All rights reserved.
 *
 */

#include <Cocoa/Cocoa.h>
#include <Carbon/Carbon.h>
#include "SDL.h"
#include "SDLMain.h"